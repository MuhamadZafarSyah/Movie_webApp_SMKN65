<?php $__env->startSection('admin_content'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-moviesmkn65\resources\views/dashboard/movie/create.blade.php ENDPATH**/ ?>