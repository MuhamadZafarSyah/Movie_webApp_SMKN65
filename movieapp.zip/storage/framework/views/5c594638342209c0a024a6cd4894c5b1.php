<?php $__env->startSection('admin_content'); ?>
    
    <main>
        <h1>Movie Kamu</h1>
        <a href="/dashboard/movie/create">
            <button>Buat Movie Baru</button>
        </a>
        <div class="grid grid-cols-1 md:grid-cols-2">

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-moviesmkn65\resources\views/dashboard/movie/index.blade.php ENDPATH**/ ?>