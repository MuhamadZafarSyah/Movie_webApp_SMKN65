<?php $__env->startSection('tailwindcss'); ?>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.15/dist/tailwind.min.css" rel="stylesheet">

<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('admin_content'); ?>
    <div class="mt-20 p-4 hiddenscroll">
        <h2 class="darkmode mb-4 text-xl font-bold text-gray-900 dark:text-white" id="darkmode">Tambahkan Data Movie</h2>
        <form action="<?php echo e(route('movie.update', $movie->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="grid gap-4 grid-cols-1 lg:grid-cols-2 sm:gap-6">
                <div class="col-span-2 lg:col-span-1">
                    <label id="darkmode" for="judul"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Judul Film</label>
                    <input id="input" type="text" name="judul" id="judul"
                        value="<?php echo e(old('judul', $movie->judul)); ?>"
                        class="darkmode <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan judul film.." required>
                    <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="w-full col-span-2 lg:col-span-1">
                    <label id="darkmode" for="genre"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Genre</label>
                    <input id="input" type="text" name="genre" id="genre"
                        value="<?php echo e(old('genre', $movie->genre)); ?>"
                        class="darkmode <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan genre film.." required>
                    <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="w-full col-span-2 lg:col-span-1">
                    <label id="darkmode" for="link_movie"
                        class="darkmode block mb-2 text-sm font-medium text-gray-900 dark:text-white">Link Full
                        Movie(Youtube)</label>
                    <input id="input" type="text" name="link_movie" id="link_movie"
                        value="<?php echo e(old('link_movie', $movie->link_movie)); ?>"
                        class="darkmode <?php $__errorArgs = ['link_movie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border darkmode border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan Link Full Movie.." required>
                    <?php $__errorArgs = ['link_movie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="w-full col-span-2 lg:col-span-1">
                    <label id="darkmode" for="link_trailer"
                        class="darkmode block mb-2 text-sm font-medium text-gray-900 dark:text-white">Link
                        Trailer(Youtube)</label>
                    <input id="input" type="text" name="link_trailer" id="link_trailer"
                        value="<?php echo e(old('link_trailer', $movie->link_trailer)); ?>"
                        class="darkmode <?php $__errorArgs = ['link_trailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border darkmode border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan Link Trailer.." required>
                    <?php $__errorArgs = ['link_trailer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-span-2 lg:col-span-1">
                    <label id="darkmode" for="actor"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Nama Actor</label>
                    <input type="text" name="actor" id="actor" value="<?php echo e(old('actor', $movie->actor)); ?>"
                        class="darkmodebg darkmode <?php $__errorArgs = ['actor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan Nama Actor">
                    <?php $__errorArgs = ['actor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-span-2 lg:col-span-1">
                    <label id="darkmode" for="sutradara"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Sutradara</label>
                    <input type="text" name="sutradara" id="sutradara" value="<?php echo e(old('sutradara', $movie->sutradara)); ?>"
                        class="darkmodebg darkmode <?php $__errorArgs = ['sutradara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan Nama Sutradara">
                    <?php $__errorArgs = ['sutradara'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-span-2 lg:col-span-1">
                    <label id="darkmode" for="tahun"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Tahun
                        Pembuatan</label>
                    <input type="text" name="tahun" id="tahun" value="<?php echo e(old('tahun', $movie->tahun)); ?>"
                        class="darkmodebg darkmode <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Masukan Tahun Pembuatan">
                    <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-span-2 lg:col-span-1">
                    <label id="darkmode" for="rating"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Rating </label>
                    <input type="text" name="rating" id="rating" value="<?php echo e(old('rating', $movie->rating)); ?>"
                        class="darkmodebg darkmode <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Cth: 8.3">
                    <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-span-2 lg:col-span-1">
                    <label id="darkmode" for="durasi"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode">Durasi</label>
                    <input type="text" name="durasi" id="durasi" value="<?php echo e(old('durasi', $movie->durasi)); ?>"
                        class="darkmodebg darkmode <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-700 border <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-600 focus:border-blue-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        placeholder="Cth: 1 jam 20 menit">
                    <?php $__errorArgs = ['durasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class=" text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="w-full col-span-2">
                    <label id="darkmode" id="input"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode"
                        for="image">Banner
                        Gambar</label>
                    <input type="hidden" name="oldImage" value="<?php echo e($movie->gambar); ?>">
                    <?php if($movie->gambar): ?>
                        <img src="/storage/<?php echo e($movie->gambar); ?>" class="img-preview mb-2 w-1/2 -z-50 object-cover">
                    <?php else: ?>
                        <img class="img-preview mb-2 w-1/2 -z-50 object-cover">
                    <?php endif; ?>
                    <input onchange="previewImage()"
                        class="<?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            border-red-700 border
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> block w-full p-1 text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer dark:text-gray-400 focus:outline-none  dark:border-gray-600 dark:placeholder-gray-400"
                        aria-describedby="file_input_help" id="image" name="gambar" type="file">
                    <p class="mt-1 text-sm  text-gray-900 dark:text-white" id="file_input_help">PNG, JPG or JPEG (MAX.
                        30mb).</p>
                    <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="absolute text-xs text-red-500"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="col-span-2">
                    <label id="darkmode" id="input"
                        class="block mb-2 text-sm font-medium text-gray-900 dark:text-white darkmode"
                        for="image">Deskripsi Singkat</label>
                    <input type="hidden" id="deskripsi" name="deskripsi"
                        value="<?php echo e(old('deskripsi', $movie->deskripsi)); ?>">
                    <textarea class="form-control deskripsi darkmode darkmodebg" id="deskripsi" input="deskripsi" name="deskripsi"></textarea>

                </div>
            </div>
            <button type="submit"
                class="inline-flex items-center px-5 mt-4  py-2.5   text-sm font-medium text-center text-white bg-blue-700 rounded-lg focus:ring-4 focus:ring-blue-200 dark:focus:ring-blue-900 hover:bg-blue-800">
                Publish
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<script>
    function previewImage() {
        const image = document.querySelector("#image");
        const imgPreview = document.querySelector("#img-preview");

        // Menampilkan preview hanya jika file telah dipilih
        if (image.files && image.files[0]) {
            imgPreview.style.display = "block";

            const oFReader = new FileReader();
            oFReader.readAsDataURL(image.files[0]);

            oFReader.onload = function(oFREvent) {
                imgPreview.src = oFREvent.target.result;
            };
        }
    }
</script>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-moviesmkn65\resources\views/dashboard/edit.blade.php ENDPATH**/ ?>