<footer class="footer">
    <div class="container">


        <div class="row">
            <div class="col-12">
                <div class="footer__content">
                    <small class="footer__copyright" style="text-align: center">© 2024 Copyright LVX Cinema All right
                        Reserved.</small>
                </div>
            </div>
        </div>
    </div>
</footer>
